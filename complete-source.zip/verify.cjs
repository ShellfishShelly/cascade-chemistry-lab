const fs=require('fs'),vm=require('vm'),assert=require('assert');
const d=JSON.parse(fs.readFileSync('dist/data.json'));
const elements=new Map; const el=s=>{if(!elements.has(s))elements.set(s,{});return elements.get(s)};
const ctx={document:{querySelector:el,addEventListener:()=>{}},fetch:()=>({then:()=>({then:()=>({catch:()=>{}})})}),console,structuredClone};vm.createContext(ctx);vm.runInContext(fs.readFileSync('dist/app.js','utf8'),ctx);ctx.d=d;vm.runInContext('data=d;valid(d)',ctx);
assert.equal(d.recipes.length,32);assert.equal(Object.values(d.distillations).reduce((a,x)=>a+x.sources.length,0),137);
for(const [name,it] of Object.entries(d.items)){const b=fs.readFileSync('dist/'+it.icon);assert.equal(b.toString('ascii',0,4),'RIFF',name);assert.equal(b.toString('ascii',8,12),'WEBP',name)}
for(const r of d.recipes)for(const q of [1,2,3,5,10,99]){ctx.r=r;ctx.q=q;const p=vm.runInContext('plan(r,q)',ctx);assert(p.produced>=q);assert(p.produced-q<r.yield);for(const x of r.inputs)for(const s of d.distillations[x.dist].sources){const need=x.count*p.batches,n=Math.ceil(need/s.yield);assert(n*s.yield>=need);assert((n-1)*s.yield<need)}}
ctx.r=d.recipes.find(r=>r.name==='Speedy Tincture');assert.equal(vm.runInContext('plan(r,5).produced',ctx),6);assert.equal(vm.runInContext('plan(r,5).runs',ctx),1);
ctx.r=d.recipes.find(r=>r.name==='Reforge Coating');assert.equal(vm.runInContext('plan(r,5).batches',ctx),5);
console.log('Verified all 32 recipes; 137 source yields; 186 valid WebP icons; rounding and capacity across six target amounts.');

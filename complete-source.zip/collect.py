import re,json,html,subprocess,concurrent.futures,pathlib
root=pathlib.Path('/workspace/sites/abiotic-chemistry'); cache=pathlib.Path('/workspace/scratch/db7e46ca9846/pages');cache.mkdir(exist_ok=True)
s=pathlib.Path('/workspace/scratch/db7e46ca9846/db.html').read_text()
def clean(s):return html.unescape(re.sub('<[^>]*>','',s)).strip()
tables=re.findall(r'<table.*?</table>',s,re.S)
items={}; dist={};recipes=[]
def item(cell):
 href,name=re.search(r'<a href="([^"]+)"[^>]*>(.*?)</a>',cell).groups();name=clean(name);items[name]={'url':'https://www.abioticdatabase.com'+href};return name
for tr in re.findall(r'<tr>(.*?)</tr>',tables[1],re.S)[1:]:
 td=re.findall(r'<td>(.*?)</td>',tr,re.S);name=item(td[0]);sources=[]
 for a,n in re.findall(r'(<a .*?</a>)\s+(\d+)',td[2]):sources.append({'item':item(a),'yield':int(n)})
 dist[name.replace(' Distillation','')]={'name':name,'sources':sources}
for idx,cat in [(3,'Flask'),(4,'Tincture'),(5,'Coating')]:
 for tr in re.findall(r'<tr>(.*?)</tr>',tables[idx],re.S)[1:]:
  td=re.findall(r'<td>(.*?)</td>',tr,re.S);name=item(td[0]);recipes.append({'name':name,'category':cat,'yield':int(clean(td[1])),'inputs':[{'dist':d.strip(),'count':int(n)} for n,d in re.findall(r'(\d+) ([A-Za-z]+)',clean(td[2]))],'description':clean(td[3]).split(' (')[0]})
items['Unstable Flask']={'url':'https://www.abioticdatabase.com/items/unstable-flask/'}
recipes.append({'name':'Unstable Flask','category':'Flask','yield':1,'inputs':[{'dist':'Noxious Sludge','count':1},{'dist':'Vigorous','count':1},{'dist':'Alien','count':1}],'special':True,'description':'Failed concoction with unpredictable effects. This calculator uses the sludge route: 1 Noxious Sludge plus 1 each of two chosen distillations. Other invalid mixtures can also produce this flask.'})
(root/'dist/icons').mkdir(exist_ok=True)
def fetch(t):
 name,v=t;slug=v['url'].rstrip('/').split('/')[-1];p=cache/(slug+'.html')
 if not p.exists():subprocess.run(['curl','-L','-s','--fail','--max-time','25',v['url'],'-o',str(p)])
 if not p.exists():return name,'page failed'
 h=p.read_text();m=re.search(r'<img[^>]+src="(/img/[^"]+)"',h)
 if not m:return name,'no icon'
 url='https://www.abioticdatabase.com'+m[1];out=root/'dist/icons'/(slug+'.webp')
 subprocess.run(['curl','-L','-s','--fail','--max-time','25',url,'-o',str(out)])
 v['icon']='icons/'+slug+'.webp';v['iconSource']=url
 return name,out.stat().st_size if out.exists() else 'download failed'
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
 for name,result in ex.map(fetch,items.items()):
  if isinstance(result,str):print(name,result,flush=True)
(root/'dist/data.json').write_text(json.dumps({'version':'1.4 reference — 1.5 costs not yet verified','checked':'2026-10-27','recipes':recipes,'distillations':dist,'items':items},indent=2))
print('DONE',len(recipes),len(dist),len(items),flush=True)
